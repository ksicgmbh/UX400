/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"sap/training/aggregation_binding/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});