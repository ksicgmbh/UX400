sap.ui.define([
	"sap/training/aggregation_binding/test/unit/controller/Main.controller"
], function () {
	"use strict";
});