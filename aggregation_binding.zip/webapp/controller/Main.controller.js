sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.training.aggregation_binding.controller.Main", {
		
		onInit: function(){
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("model/data.json");
			this.getView().setModel(oModel, "connections");
		}
		
	});
});