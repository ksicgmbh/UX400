sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.sap.Localization.controller.Main", {
		onInit: function () {
			
		},
		
		onRatingChange: function(oEvent){
			var nValue = oEvent.getSource().getValue();
			var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var oText = this.getView().byId("idText");
			var sLocText = oResourceBundle.getText("flightRating", [nValue, "123", "asd"]);
			
			oText.setText(sLocText);
		},
		
		onLangChanged: function(oEvent){
			var sKey = oEvent.getSource().getSelectedKey();
			
			this.getOwnerComponent().changeLang(sKey);
		}
	});
});