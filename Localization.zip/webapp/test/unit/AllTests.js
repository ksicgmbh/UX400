sap.ui.define([
	"com/sap/Localization/test/unit/controller/Main.controller"
], function () {
	"use strict";
});