/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/sap/Localization/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});