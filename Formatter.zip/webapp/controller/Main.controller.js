sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.sap.Formatter.controller.Main", {
		onInit: function () {
		},
		
		carrNameFormatter: function(sCarrId){
			switch(sCarrId){
				case "LH": 
					return "Lufthansa";
				case "JL": 
					return "Japan Airlines";
				default: 
					return sCarrId;
			}
		}
	});
});