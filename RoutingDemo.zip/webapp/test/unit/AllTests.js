sap.ui.define([
	"com/sap/RoutingDemo/test/unit/controller/App.controller"
], function () {
	"use strict";
});