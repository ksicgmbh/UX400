sap.ui.define([
	"sap/training/element_binding/test/unit/controller/Main.controller"
], function () {
	"use strict";
});