sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.training.element_binding.controller.Main", {

		onInit: function(){
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("model/data.json");
			this.getView().setModel(oModel);
		},
		
		onCarrierSelectionChange: function(oEvent){
			this.getView().byId("connTable").bindElement(oEvent.getSource().getBindingContextPath());
			/*
			var oSelectedItem = oEvent.getParameter("listItem");
			var sPath = oSelectedItem.getBindingContextPath();
			//var oObject = this.getView().getModel().getObject(sPath);
			var oTable = this.getView().byId("connTable");
			oTable.bindElement(sPath);
			*/
		}

	});
});