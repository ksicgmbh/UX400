sap.ui.define([
	"com/sap/DialogDemo/test/unit/controller/Main.controller"
], function () {
	"use strict";
});