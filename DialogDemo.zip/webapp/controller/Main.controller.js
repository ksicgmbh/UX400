sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment"
], function (Controller, Fragment) {
	"use strict";

	return Controller.extend("com.sap.DialogDemo.controller.Main", {
		onInit: function () {

		},
		
		onDialogPressed: function(){
			var oView = this.getView();
			
			if (!this.byId("idDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.sap.DialogDemo.view.MyDialog",
					controller: this
				}).then(function(oDialog){
					
					oDialog.open();
				}.bind(this));
			} else {
				this.byId("idDialog").open();
			}
		},
		
		onCloseDialog: function(){
			
			
			var oInput = this.byId("idInput");
			var oInput2 = this.byId("idInput2");
			var oText = this.byId("idText");
			var sValue = oInput.getValue();
			
			if(!sValue || sValue === ""){
				this.invalidateField(oInput);
				this.invalidateField(oInput2);
			}else{
				oText.setText(sValue);
				this.byId("idDialog").close();
			}
			
			
		},
		
		invalidateField: function(oInput){
			oInput.setValueState("Error");
			oInput.setValueStateText("Bitte dieses Feld ausfüllen!");
			sap.m.MessageToast.show("Bitte alle Pflichtfelder ausfüllen!");
		}
	});
});