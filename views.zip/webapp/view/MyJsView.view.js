sap.ui.jsview("student00.sap.training.views.view.MyJsView", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf student00.sap.training.views.view.MyJsView
	 */
	getControllerName: function () {
		return "student00.sap.training.views.controller.MyJsView";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf student00.sap.training.views.view.MyJsView
	 */
	createContent: function (oController) {
		var oText = new sap.m.Text({
			text: "Text on Javascript View"
		});
		
		var oCheckBox = new sap.m.CheckBox(this.createId("idCheckBox"), {
			text: "No"
		});
		
		oCheckBox.attachSelect(oController.onCBSelect, oController);
		
		return [oText, oCheckBox];
	}

});