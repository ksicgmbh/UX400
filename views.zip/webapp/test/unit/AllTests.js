sap.ui.define([
	"student00/sap/training/views/test/unit/controller/MyXMLView.controller"
], function () {
	"use strict";
});