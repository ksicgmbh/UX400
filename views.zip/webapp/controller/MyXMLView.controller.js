sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("student00.sap.training.views.controller.MyXMLView", {
		onCBSelect: function(){
			var oCheckBox = this.getView().byId("idCheckBox");
			
			if(oCheckBox.getSelected()){
				oCheckBox.setText("Yes");
			}else{
				oCheckBox.setText("No");
			}
		}
	});
});