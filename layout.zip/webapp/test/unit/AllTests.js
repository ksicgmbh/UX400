sap.ui.define([
	"sap/training/layout/test/unit/controller/Main.controller"
], function () {
	"use strict";
});