sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("com.sap.ODataDemo.controller.Main", {
		onInit: function () {

		},
		
		onFlightPressed: function(oEvent){
			var sPath = oEvent.getSource().getBindingContextPath();
			this.myPath = sPath;
			var oTable = this.getView().byId("bookingTable");
			this.getView().bindElement(sPath);
		},
		
		onCreateBooking: function(){
			var oFlight = this.getView().getModel().getObject(this.myPath);
			var sCarrId = oFlight.Carrid;
			var sConnId = oFlight.Connid;
			var oFlDate = oFlight.Fldate;
			
			var oBookingData = {
				Carrid: sCarrId,
				Connid: sConnId,
				Fldate: oFlDate,
				Customid: "154",
				Passname: "Daniel Krancz",
				Counter: "1"
			};
			
			var oModel = this.getView().getModel();
			
			oModel.create("/UX_C_Booking_TP", oBookingData, {
				success: function(oData){
					MessageBox.success("Booking created with booking number " + oData.Bookid);
					var oSorter = new sap.ui.model.Sorter("OrderDate", true);  
					this.getView().byId("bookingTable").getBinding("items").sort(oSorter);
				}.bind(this),
				
				error: function(){
					MessageBox.error("Fehler!");
				}.bind(this)
			});
		},
		
		onDeleteBooking: function(oEvent){
			var sCarrid = oEvent.getSource().data("carrid");
			var sBookid = oEvent.getSource().data("bookid");
			
			var oModel = this.getView().getModel();
			
			oModel.callFunction("/CancelBooking", {
				method: "POST",
				urlParameters: {
					Bookid: sBookid,
					Carrid: sCarrid
				},
				error: function(oError){
					var oMsg = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(oMsg.error.innererror.errordetails[0].message);
				}
			});
			
			/*
			var sPath = oEvent.getSource().getBindingContextPath();
			var oODataModel = this.getView().getModel();
			oODataModel.remove(sPath, {
				success: function(){
					sap.m.MessageToast.show("Wurde gelöscht!");
				},
				error: function(oError){
					sap.m.MessageToast.show("Sorry, wurde nicht gelöscht!");
				}
			});
			*/
		}
	});
});