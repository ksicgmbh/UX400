sap.ui.define([
	"com/sap/ODataDemo/test/unit/controller/Main.controller"
], function () {
	"use strict";
});