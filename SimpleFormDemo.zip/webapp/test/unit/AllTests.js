sap.ui.define([
	"com/sap/SimpleFormDemo/test/unit/controller/Main.controller"
], function () {
	"use strict";
});