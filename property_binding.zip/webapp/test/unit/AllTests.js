sap.ui.define([
	"sap/training/property_binding/test/unit/controller/Main.controller"
], function () {
	"use strict";
});